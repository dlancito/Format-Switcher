const FORMATS = ["mp4", "mov", "avi", "m4v", "m4a"];

let formatIndex = 0;

function buildTestUrl(baseUrl, format) {
  const url = new URL(baseUrl);

  // Replace ANY extension, not just .pdf
  url.pathname = url.pathname.replace(/\.\w+$/, "") + "." + format;

  return url.toString();
}

function updateBadge(format) {
  browser.browserAction.setBadgeText({ text: format.toUpperCase() });
  browser.browserAction.setBadgeBackgroundColor({ color: "#3333cc" });
}

updateBadge(FORMATS[formatIndex]);

browser.browserAction.onClicked.addListener(async (tab) => {
  if (!tab?.url) {
    console.warn("[Format Switcher] No active tab URL found.");
    return;
  }

  let baseUrl;
  try {
    baseUrl = new URL(tab.url);
  } catch (e) {
    console.error("[Format Switcher] Invalid URL:", tab.url, e);
    return;
  }

  const lowerPath = baseUrl.pathname.toLowerCase();

  const isSupportedFormat =
    lowerPath.endsWith(".pdf") ||
    FORMATS.some(f => lowerPath.endsWith("." + f));

  // Restrict to DOJ Epstein dataset + supported formats
  if (
    baseUrl.hostname !== "www.justice.gov" ||
    !lowerPath.includes("/epstein/files/") ||
    !isSupportedFormat
  ) {
    console.warn("[Format Switcher] Not a supported DOJ Epstein file.");
    return;
  }

  const format = FORMATS[formatIndex];

  let testUrl;
  try {
    testUrl = buildTestUrl(tab.url, format);
  } catch (e) {
    console.error(`[Format Switcher] Failed to build URL for format "${format}":`, e);
    return;
  }

  try {
    await browser.tabs.update(tab.id, { url: testUrl });

    formatIndex = (formatIndex + 1) % FORMATS.length;
    updateBadge(FORMATS[formatIndex]);
  } catch (e) {
    console.error(`[Format Switcher] Failed to update tab for ${testUrl}:`, e);
  }
});